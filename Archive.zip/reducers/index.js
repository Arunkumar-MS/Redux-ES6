import { combineReducers } from 'redux';
import ui from './ui';
export default combineReducers({
  ui
});
