

export function showNextSlot(dispatch, value) {



          dispatch({
              type: 'nextSlot',
              value: value
          });

}
